# NOVA TV

Starter Android TV launcher for Xiaomi TV Box S (2nd Gen).

## Build
1. Install Android Studio (stable) with Android SDK Platform 35 and JDK 17.
2. Open this folder as a project.
3. Let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Install
Copy the APK to the TV Box and install it, or use ADB:
`adb install -r app/build/outputs/apk/debug/app-debug.apk`

Press Home and choose NOVA TV. To make it the default home app, select **Always** if Android TV offers that choice. You can change the default later in system settings.

## Current starter features
- Android TV / Leanback launcher entry point
- D-pad focus and click support
- Automatically lists launchable apps installed on the device
- Launches apps when selected
- 1080p-friendly landscape layout and dark NOVA styling

This is a starter build, not a replacement firmware. The settings and power sidebar icons are visual placeholders in this first version.
