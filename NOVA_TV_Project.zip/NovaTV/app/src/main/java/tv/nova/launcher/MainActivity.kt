package tv.nova.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.KeyEvent
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 15, 29)
    private val muted = Color.rgb(171, 181, 202)
    private val accent = Color.rgb(122, 151, 255)
    private lateinit var appRow: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildHome()
    }

    private fun buildHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(26), dp(18), dp(30), dp(24))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(22, 31, 58), Color.rgb(11, 17, 32), Color.rgb(7, 10, 20))
            )
        }

        val side = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(dp(58), ViewGroup.LayoutParams.MATCH_PARENT)
        }
        listOf("⌂", "⌕", "▣", "⚙", "⏻").forEachIndexed { index, symbol ->
            val item = TextView(this).apply {
                text = symbol
                textSize = 25f
                gravity = Gravity.CENTER
                setTextColor(if (index == 0) Color.WHITE else muted)
                background = if (index == 0) rounded(accent, 18) else null
                isFocusable = true
                isFocusableInTouchMode = true
                contentDescription = listOf("Главная", "Поиск", "Приложения", "Настройки", "Выключение")[index]
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply {
                    bottomMargin = dp(17)
                }
                setOnClickListener {
                    if (index == 4) Toast.makeText(this@MainActivity, "Выключение доступно через меню Android TV", Toast.LENGTH_SHORT).show()
                    else if (index == 3) Toast.makeText(this@MainActivity, "Настройки приставки доступны через системное меню", Toast.LENGTH_SHORT).show()
                }
            }
            side.addView(item)
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(2), 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "NOVA"
            textSize = 15f
            letterSpacing = .22f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        val spacer = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }
        val clock = TextClock(this).apply {
            format12Hour = "HH:mm"
            format24Hour = "HH:mm"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        top.addView(brand)
        top.addView(spacer)
        top.addView(clock)
        content.addView(top)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(0, dp(34), 0, dp(20))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val title = TextView(this).apply {
            text = "Главная"
            textSize = 35f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "Ваши приложения"
            textSize = 15f
            setTextColor(muted)
            setPadding(0, dp(5), 0, 0)
        }
        hero.addView(title)
        hero.addView(subtitle)
        content.addView(hero)

        val section = TextView(this).apply {
            text = "ПРИЛОЖЕНИЯ"
            textSize = 11f
            letterSpacing = .16f
            setTextColor(muted)
            setPadding(0, 0, 0, dp(12))
        }
        content.addView(section)

        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipToPadding = false
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(112))
        }
        appRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        scroller.addView(appRow)
        content.addView(scroller)

        root.addView(side)
        root.addView(content)
        setContentView(root)
        populateApps()
    }

    private fun populateApps() {
        appRow.removeAllViews()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps: List<ResolveInfo> = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        apps.forEach { info ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = rounded(Color.argb(150, 34, 44, 67), 18)
                isFocusable = true
                isFocusableInTouchMode = true
                layoutParams = LinearLayout.LayoutParams(dp(142), dp(94)).apply {
                    rightMargin = dp(13)
                }
                setOnFocusChangeListener { view, focused ->
                    view.animate().scaleX(if (focused) 1.07f else 1f)
                        .scaleY(if (focused) 1.07f else 1f).setDuration(140).start()
                    view.background = rounded(
                        if (focused) Color.rgb(103, 130, 224) else Color.argb(150, 34, 44, 67),
                        18
                    )
                }
                setOnClickListener { launchApp(info) }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(info.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(38), dp(38))
            }
            val label = TextView(this).apply {
                text = info.loadLabel(packageManager)
                textSize = 12f
                maxLines = 1
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(5), dp(7), dp(5), 0)
            }
            tile.addView(icon)
            tile.addView(label)
            appRow.addView(tile)
        }

        if (appRow.childCount > 0) appRow.getChildAt(0).requestFocus()
        else {
            val empty = TextView(this).apply {
                text = "Не найдено приложений"
                setTextColor(muted)
                textSize = 14f
            }
            appRow.addView(empty)
        }
    }

    private fun launchApp(info: ResolveInfo) {
        val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
        if (launch != null) startActivity(launch)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
